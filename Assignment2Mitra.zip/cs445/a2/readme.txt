I added some extra functionality for extra credit. 
My evaluate method tests for divide by zero and I added a modulus operation. 