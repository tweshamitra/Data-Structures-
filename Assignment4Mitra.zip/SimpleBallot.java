/*
	Twesha Mitra
	CS 401 Summer
	Assignment 4
	SimpleBallot Class
	This SimpleBallot class simulates an election in a very simple way using the BallotInterface. 
	In the initialize() method, the user is simply welcomed. In the isValid() method, the user 
	is asked a simple question and if answered correctly, he/she is given the option to vote. 
	Then, the continueVoting() method simply asks the user if he/she wants to vote at the moment. 
	If yes, then the program continues. The nextVoter() displays some options for the user to vote for. 
	The user keeps voting until he/she selects "no".Then, the finalize() method simply displays a message 
	showing what the user voted for and exits the program. 
*/

import java.util.*;
import javax.swing.*;
import java.awt.*;

public class SimpleBallot implements BallotInterface{
	boolean s=true;
	Scanner sc= new Scanner(System.in);
	private String [] offices={"Best Ice Cream Flavor", "Best Movie", "Best Programming Language"};
	private String input;
	private String [] icecream= {"Chocolate", "Strawberry", "Vanilla"};
	private String icecreamflavor;
	private String [] movies={"Avengers: Age of Ultron", "Captain America: Civil War", "The Wizard of Oz"};
	private String movie;
	private String [] programminglang={"Java", "C", "C++"};
	private String lang;
	private String name;
	public SimpleBallot(Scanner s){
	}
	
	public void initialize(){	
		JOptionPane.showMessageDialog(null, "Welcome!");
	}
	
	public boolean isValid(){
		String ans= JOptionPane.showInputDialog("What is the last name of the current President of the United States?");
			if(ans.equalsIgnoreCase("obama"))
				return true;
			else return false;
	}
	
	public boolean continueVoting(){ 
		int option=JOptionPane.showConfirmDialog(null,"Would you like to vote?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if(option==JOptionPane.YES_OPTION)
			return true;
		else 
			return false;
	}
	
	public void nextVoter(){
			input= (String)JOptionPane.showInputDialog(null,"Choose now", "Choose the office you wish to vote for: ", JOptionPane.QUESTION_MESSAGE,null, offices, offices[0]);
			if(input.equalsIgnoreCase("best ice cream flavor"))
				{
				icecreamflavor= (String)JOptionPane.showInputDialog(null,"Choose now", "Choose your favorite ice cream flavor: ", JOptionPane.QUESTION_MESSAGE,null, icecream, icecream[0]);
				JOptionPane.showMessageDialog(null, "You voted for: " + icecreamflavor);
				}
			else if(input.equalsIgnoreCase("best movie"))
				{
				movie= (String)JOptionPane.showInputDialog(null,"Choose now", "Choose your favorite movie ", JOptionPane.QUESTION_MESSAGE,null, movies, movies[0]);
				JOptionPane.showMessageDialog(null, "You voted for: " + movie);
				}
			else if(input.equalsIgnoreCase("best programming language"))
				{
				lang= (String)JOptionPane.showInputDialog(null,"Choose now", "Choose your favorite programming language: ", JOptionPane.QUESTION_MESSAGE,null, programminglang, programminglang[0]);
				JOptionPane.showMessageDialog(null, "You voted for: " + lang);
				}	
	}
	
	public void finalize(){
		JOptionPane.showMessageDialog(null, "Here are your votes:");
		JOptionPane.showMessageDialog(null, "Favorite Ice Cream Flavor: " + icecreamflavor + "\nFavorite Movie: " + movie + "\nFavorite Programming Language: " + lang); 
		JOptionPane.showMessageDialog(null, "Thank you for casting your votes!");
	}
}