/*
	Twesha Mitra
	CS 401 Summer
	Assignment 4
	BetterBallot Class
	This class implements the BallotInterface provided. In this class, there is a Voter 
	class and a BallotItem class to represent individual voters and ballots. In the
	initialize() method, the user is prompted for a file name until the specified file is found. 
	This method also reads in the data from the text files and stores it in the Voter class. 
	The isValid() method always returns true because the user must enter a filename that can be found. 
	Therefore, the Assig4.java program is never terminated because of a problem. 
	The continueVoting() method asks the administrator for an ID that is stored in a file.
	If the administrator incorrectly enters the ID twice, the program terminates. The finalize() 
	method attempts to saves the data and close the program in an elegant way. 
*/
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class BetterBallot implements BallotInterface{
	private Scanner sc= new Scanner(System.in);
	FileWriter fw;
	BufferedWriter bw;
	private File infile;
	private Scanner filein;
	private String path;
	private String token;
	private String adminfile;
	private String input;
	private String [] details;
	private String [] everything;
	private String [] candidates;
	private ArrayList<Voter> voters= new ArrayList<Voter>();
	private ArrayList<BallotItem> ballots= new ArrayList<BallotItem>();
	private ArrayList<Integer> adminid= new ArrayList<Integer>();
	private ArrayList<Integer> ballotids= new ArrayList<Integer>();
	private ArrayList<String> candidatelist= new ArrayList<String>();
	private ArrayList<String> offices= new ArrayList<String>();
	Object [] officesvote;
	String voterfile;
	String ballotfile;
	Voter v;
	BallotItem b;
	private boolean flag=true;
	public BetterBallot(Scanner s){
	}
	
	public void initialize() {
		while(true){
			try	{
				System.out.println("Please enter Admin file name: ");
				adminfile=sc.nextLine();
				infile= new File(adminfile);
				filein= new Scanner(infile);	
					while(filein.hasNext()){
						token=filein.next();
						adminid.add(Integer.parseInt(token));
					}
				break;
			} catch (FileNotFoundException e) {
				System.out.println("File was not found. Try again: ");
				
			}
		}
		while(true){
			try	{
				System.out.println("Please enter Voter file name: ");
				voterfile=sc.nextLine();
				infile=new File(voterfile);
				filein=new Scanner(infile);
				while(filein.hasNext()){
					v= new Voter();
					String line=filein.nextLine();
					details=line.split(":");
					int id=Integer.parseInt(details[0]);
					v.setID(id);	
					String name=details[1];
					v.setName(name);
					Boolean voted=Boolean.parseBoolean(details[2]);
					v.setVoted(voted);
					voters.add(v);
				}
				break;
			} catch (FileNotFoundException e1) {
			System.out.println("File not found. Try again: ");	
			}
		}
		while(true){	
			try{
				System.out.println("Please enter Ballot file name: ");
				ballotfile=sc.nextLine();
				infile=new File(ballotfile);
				filein=new Scanner(infile);
				while(filein.hasNext()){
					b= new BallotItem();
					String line_two=filein.nextLine();
					everything=line_two.split(":");
					
					int ballotid= Integer.parseInt(everything[0]);
					b.setID(ballotid);
					String office= everything[1];
					b.setOffice(office);
					offices.add(office);
					candidates=(everything[2]).split(",");
					ballots.add(b);
				}
					officesvote=offices.toArray();
				break;
			} catch(FileNotFoundException e2) {
				System.out.println("File not found. Try again: ");
			}
		}
		
	}

	public boolean isValid() {
		if(flag==true)
		{
			flag=false;
			return true;
		} 
		else
			return false;
	}
	
	public boolean continueVoting() {
		int input;
			System.out.println("Administrator, please authorize next voter: ");
			input=sc.nextInt();
		if(adminid.contains(input))
			{
			System.out.println("Thank you, next voter can vote now.");
			return true;
			}
		else {
			System.out.println("The ID entered was not found. Please try again: ");
			input=sc.nextInt();
				if(adminid.contains(input))	
				{
					System.out.println("Thank you, next voter can vote now.");
					return true;
				}				
		return false;
		}
	}
	
	public void nextVoter(){
		int idattempt=Integer.parseInt(JOptionPane.showInputDialog("Voter, please enter your voter id: "));
		for(int i=0; i<voters.size(); i++){
			if(idattempt==(voters.get(i)).getID())	
				{
					JOptionPane.showMessageDialog(null, "Welcome, " +voters.get(i).getName() + "!\nPlease vote for each office on the ballot");	
					for (int x=0; x<officesvote.length; x++){
						String choice= ballots.get(x).getoffice();
						String input= (String)JOptionPane.showInputDialog(null, "Choose", choice, JOptionPane.QUESTION_MESSAGE, null, candidates, candidates[0]);
						JOptionPane.showConfirmDialog(null,"Submit vote?");
						path=everything[0];
						File file2= new File(path);
						if(!file2.exists())
						try{
						file2.createNewFile();
						fw= new FileWriter(file2.getAbsoluteFile());
						bw= new BufferedWriter(fw);
						bw.write("hello");
						bw.close();
						} catch(IOException e){
							e.printStackTrace();
						}
						v.setVoted(true);
						}
					
				break;
				}	
			
			}
	}
	
	public void finalize(){
		System.out.println("Voting is finished");
		System.out.println("Administrator,  please see the following files: ");
		System.out.println(voterfile + ": updated voters file");
	}
	
	class Voter {
		private String name;
		private int id;
		private boolean voted;
		public Voter(){
			}
		public void setID(int x){
			id=x;
		}
		
		public int getID(){
			return id;
		}
		
		public void setName(String n){
			name=n;
		}
		public String getName(){
			return name;
		}
		
		public void setVoted(boolean b){
			voted=b;
		}
		public boolean getVoted(){
			return voted;
		}
	}
	
	class BallotItem{
		private int id;
		private String office;
		private String [] candidateslist;
		
		public BallotItem(){}
	
		public void setID(int a){
			id=a;
		}
		
		public void setOffice(String o){
			office=o;
		}
		
		public int getID(){
			return id;
		}
		
		public String getoffice(){
			return office;
		}
		
		public void setCandidateList(String [] a) {
			this.candidateslist=a;
			}
		
		public String getCandidate(int index) {
			return candidateslist[index];
			}
		
	}
}